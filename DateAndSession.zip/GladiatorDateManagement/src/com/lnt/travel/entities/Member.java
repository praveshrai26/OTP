package com.lnt.travel.entities;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

public class Member {
	@DateTimeFormat(pattern = "yyyy/MM/dd")
	private Date dob;
	
	public Member(){}

	
	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}


	@Override
	public String toString() {
		return "Member [dob=" + dob + "]";
	}
}
