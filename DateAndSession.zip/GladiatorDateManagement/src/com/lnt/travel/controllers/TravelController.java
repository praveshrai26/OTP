package com.lnt.travel.controllers;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.lnt.travel.entities.Member;

// http://localhost:8085/GladiatorDateManagement1/appl/memberServices/getNewMember

@Controller
@RequestMapping("/memberServices")
public class TravelController {
	
	@InitBinder
	protected void initBinder(WebDataBinder binder) {
	    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
	    binder.registerCustomEditor(Date.class, new CustomDateEditor(
	            dateFormat, false));
	}
	
	@RequestMapping("/getNewMember")
	public ModelAndView getNewMember(Model model) {
		Member member=new Member();
		ModelAndView mAndV=new ModelAndView();
		mAndV.addObject("member",member);
		mAndV.setViewName("Register");
		return mAndV;		
	}
	
	@RequestMapping(value="/addNewMember", method=RequestMethod.POST)
	public ModelAndView addNewMember( @ModelAttribute("member") Member member)
			{
		System.out.println(member);
		
		ModelAndView mAndV =new ModelAndView();
		if(member!=null){
			mAndV.setViewName("Success");
			mAndV.addObject(member);
		}			
		return mAndV;
	}
}
